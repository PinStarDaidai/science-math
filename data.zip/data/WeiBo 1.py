import json
import requests
import pprint
import pandas as pd
import openpyxl

url = "https://m.weibo.cn/api/container/getIndex?containerid=2304132028810631_-_WEIBO_SECOND_PROFILE_WEIBO&page_type=03&page={}"

# 获取十页的数据
for i in range(5):
    response = requests.get(url.format(i))
    # 数据转化为json数据结构
    data= response.json()
    # pprint.pprint(data)
    # 提取出评论列表
    cards = data['data']['cards']
    for mid in cards:
        # 判断有无 mblog 有就打印，没有就None
        if mid.get('mblog',None):
            id = mid['mblog']['mid']

            # 服务器返回内容，用变量接受
            response = requests.get(
                "https://m.weibo.cn/comments/hotflow?id={id}&mid={id}&max_id_type=0".format(id=id))
            # 字典数据
            data = response.json()
            datalist = []
            users = data.get('data', None)
            if users:
                users = users['data']

            for user in users:
                text = user['text']
                id = user['user']['id']
                name = user['user']['screen_name']
                print(text)
                print(id)
                print(name)
                # datalist.append({
                #     "用户ID": str(id),
                #     "用户名称": name,
                #     "评论信息": text.replace("<a href='", "").replace("/n", "").replace("</a>", "")
                # })
                with open('result.txt', 'a+', encoding='utf-8') as fp:
                    fp.write(str(text))
                    fp.write(str(id))
                    fp.write(str(name))
                    fp.write("\n")

            # df = pd.DataFrame(datalist)
            # df.to_excel("评论信息3.xlsx")